# 小说模板

## 目录文件说明

```
├── img             - 静态图片目录
├── font            - 静态字体目录
├── README.md       - 说明文件
├── catalog.html    - 小说章节页面
├── category.html   - 小说分类页面
├── list.html       - 小说排行榜页面
├── mybook.html     - 我的说架页面
├── read.html       - 小说阅读页面
├── view.html       - 小说详情页面
└── xiaoshuo.html   - 主页
```
